from sqlalchemy.orm import DeclarativeBase

class SampleBase(DeclarativeBase):
    pass
