class SampleDomain():
    pass
