from digitalpy.core.zmanager.impl.default_action_mapper import DefaultActionMapper


class SampleActionMapper(DefaultActionMapper):
    pass
