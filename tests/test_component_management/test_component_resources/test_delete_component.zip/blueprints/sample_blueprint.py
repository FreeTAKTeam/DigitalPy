
from flask import Blueprint, request, make_response, send_file
from digitalpy.core.network.impl.network_flask_http_blueprints import BlueprintCommunicator


page = Blueprint('sample', __name__)

@page.route('/Greeting', methods=["POST"])
def POSTGreeting():
    """TODO"""
    try:
        # send data to the NetworkInterface
        response = BlueprintCommunicator().send_message_sync(
        	"POSTGreeting",
        	"^Greeting",
        	{
        "body": request.data,
        }) # type: ignore
        return response.get_value("message")[0], 200
    except Exception as e:
    	return str(e), 500
@page.route('/Greeting', methods=["DELETE"])
def DELETEGreeting():
    """TODO"""
    try:
        # send data to the NetworkInterface
        response = BlueprintCommunicator().send_message_sync(
        	"DELETEGreeting",
        	"^Greeting",
        	{
        "ID": request.args.get('ID'),
        }) # type: ignore
        return response.get_value("message")[0], 200
    except Exception as e:
    	return str(e), 500
@page.route('/Greeting', methods=["GET"])
def GETGreeting():
    """TODO"""
    try:
        # send data to the NetworkInterface
        response = BlueprintCommunicator().send_message_sync(
        	"GETGreeting",
        	"^Greeting",
        	{
        }) # type: ignore
        return response.get_value("message"), 200
    except Exception as e:
    	return str(e), 500
@page.route('/Greeting', methods=["PATCH"])
def PATCHGreeting():
    """TODO"""
    try:
        # send data to the NetworkInterface
        response = BlueprintCommunicator().send_message_sync(
        	"PATCHGreeting",
        	"^Greeting",
        	{
        "body": request.data,
        }) # type: ignore
        return response.get_value("message")[0], 200
    except Exception as e:
    	return str(e), 500
@page.route('/Greeting/<id>', methods=["GET"])
def GETGreetingId(id,):
    """TODO"""
    try:
        # send data to the NetworkInterface
        response = BlueprintCommunicator().send_message_sync(
        	"GETGreetingId",
        	"^Greeting^",
        	{
        "ID": request.args.get('ID'),
        "id": id,
        }) # type: ignore
        return response.get_value("message")[0], 200
    except Exception as e:
    	return str(e), 500
