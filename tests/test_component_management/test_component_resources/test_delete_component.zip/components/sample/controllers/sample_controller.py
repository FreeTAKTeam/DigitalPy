"""
This is the main controller class of the application. Every operation of the controller is realized by this file
OOTB. It is recommended that you (the developper) avoid adding further methods to the file and instead add supporting
controllers with these methods should you need them. This controller is called directly by the facade in order to
fulfil any requests made to the component by default.
"""

from typing import TYPE_CHECKING, List

from digitalpy.core.main.controller import Controller
from digitalpy.core.serialization.configuration.serialization_constants import Protocols
# import builders
from tests.test_component_management.test_component_resources.components.sample.domain.builder.greeting_builder import GreetingBuilder
from tests.test_component_management.test_component_resources.components.sample.domain.builder.error_builder import ErrorBuilder
from .sample_persistence_controller import SamplePersistenceController

if TYPE_CHECKING:
    from digitalpy.core.digipy_configuration.configuration import Configuration
    from digitalpy.core.zmanager.impl.default_action_mapper import DefaultActionMapper
    from digitalpy.core.zmanager.request import Request
    from digitalpy.core.zmanager.response import Response
    from digitalpy.core.domain.domain.network_client import NetworkClient
    from tests.test_component_management.test_component_resources.components.sample.domain.model.greeting import Greeting
    from tests.test_component_management.test_component_resources.components.sample.domain.model.error import Error

class SampleController(Controller):

    def __init__(self, request: 'Request',
                 response: 'Response',
                 sync_action_mapper: 'DefaultActionMapper',
                 configuration: 'Configuration'):
        super().__init__(request, response, sync_action_mapper, configuration)
        self.Greeting_builder = GreetingBuilder(request, response, sync_action_mapper, configuration)
        self.Error_builder = ErrorBuilder(request, response, sync_action_mapper, configuration)
        self.sample_persistence_controller = SamplePersistenceController(
            request, response, sync_action_mapper, configuration)

    def initialize(self, request: 'Request', response: 'Response'):
        """This function is used to initialize the controller. 
        It is intiated by the service manager."""
        self.Greeting_builder.initialize(request, response)
        self.Error_builder.initialize(request, response)
        self.sample_persistence_controller.initialize(request, response)
        return super().initialize(request, response)
    def POSTGreeting(self, body: 'str', client: 'NetworkClient', config_loader, *args, **kwargs):  # pylint: disable=unused-argument
        """TODO"""

        # initialize Greeting builder
        self.Greeting_builder.build_empty_object(config_loader=config_loader)
        self.Greeting_builder.add_object_data(mapped_object = body, protocol=Protocols.JSON)
        domain_obj = self.Greeting_builder.get_result()

        # Save the Greeting record to the database
        self.sample_persistence_controller.save_greeting(domain_obj)

        domain_records = [domain_obj]
        # set the target
        self.response.set_value("recipients", [str(client.get_oid())])

        # return the records
        self.response.set_value("message", domain_records)

        # publish the records
        self.response.set_action("publish")

    def DELETEGreeting(self, ID: str, client: 'NetworkClient', config_loader, *args, **kwargs):  # pylint: disable=unused-argument
        """TODO"""
        db_records = self.sample_persistence_controller.get_greeting(ID = ID)
        domain_records: List['Greeting'] = []

        # convert the records to the domain object
        for record in db_records:
            self.Greeting_builder.build_empty_object(config_loader=config_loader)
            self.Greeting_builder.add_object_data(record)
            record = self.Greeting_builder.get_result()
            self.sample_persistence_controller.remove_greeting(record)
            domain_records.append(record)
        # set the target
        self.response.set_value("recipients", [str(client.get_oid())])

        # return the records
        self.response.set_value("message", domain_records)

        # publish the records
        self.response.set_action("publish")

    def GETGreeting(self, client: 'NetworkClient', config_loader, *args, **kwargs):  # pylint: disable=unused-argument
        """TODO"""
        # retrieve the Greeting record from the database
        db_records = self.sample_persistence_controller.get_all_greeting()
        domain_records: List['Greeting'] = []

        # convert the records to the domain object
        for record in db_records:
            self.Greeting_builder.build_empty_object(config_loader=config_loader)
            self.Greeting_builder.add_object_data(record)
            domain_records.append(self.Greeting_builder.get_result())
        # set the target
        self.response.set_value("recipients", [str(client.get_oid())])

        # return the records
        self.response.set_value("message", domain_records)

        # publish the records
        self.response.set_action("publish")

    def PATCHGreeting(self, body: 'Greeting',  client: 'NetworkClient', config_loader, *args, **kwargs):  # pylint: disable=unused-argument
        """TODO"""
        # create the basic domain object from the json data
        self.Greeting_builder.build_empty_object(config_loader)
        self.Greeting_builder.add_object_data(body, Protocols.JSON)
        domain_obj = self.Greeting_builder.get_result()

        # get from the database
        db_obj = self.sample_persistence_controller.get_greeting(oid=str(domain_obj.oid))[0]

        # initialize the object
        self.Greeting_builder.build_empty_object(config_loader)
        self.Greeting_builder.add_object_data(db_obj)
        # TODO: this duplaction seems unnecessary
        # update the object with json data
        self.Greeting_builder.add_object_data(body, Protocols.JSON)
        # Save the Schedule record to the database
        self.sample_persistence_controller.update_greeting(domain_obj)

        # set the target
        self.response.set_value("recipients", [str(client.get_oid())])

        # return the records
        self.response.set_value("message", [domain_obj])

        # publish the records
        self.response.set_action("publish")

    def GETGreetingId(self, ID: 'str', client: 'NetworkClient', config_loader, *args, **kwargs):  # pylint: disable=unused-argument
        """TODO"""

        # retrieve the Greeting record from the database
        db_records = self.sample_persistence_controller.get_greeting(ID = ID)
        domain_records: List['Greeting'] = []

        # convert the records to the domain object
        for record in db_records:
            self.Greeting_builder.build_empty_object(config_loader=config_loader)
            self.Greeting_builder.add_object_data(record)
            domain_records.append(self.Greeting_builder.get_result())

        # set the target
        self.response.set_value("recipients", [str(client.get_oid())])

        # return the records
        self.response.set_value("message", domain_records)

        # publish the records
        self.response.set_action("publish")

