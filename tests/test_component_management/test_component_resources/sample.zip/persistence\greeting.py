from sqlalchemy.orm import relationship, validates, Mapped, mapped_column
from sqlalchemy import ForeignKey
from typing import TYPE_CHECKING, List, Optional

from .sample_base import SampleBase

if TYPE_CHECKING:
    pass

class Greeting(SampleBase):
    """ 
    """

    __tablename__ = 'Greeting'
    oid: Mapped[str] = mapped_column(primary_key=True)
    message: Mapped[str]
    language: Mapped[str]


