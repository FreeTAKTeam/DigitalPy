from typing import TYPE_CHECKING, List, Union
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

# import tables in initialization order
from components.sample.persistence.greeting import Greeting as DBGreeting
from components.sample.persistence.error import Error as DBError

# import domain model classes
from components.sample.domain.model.greeting import Greeting
from components.sample.domain.model.error import Error

from digitalpy.core.main.controller import Controller
from components.sample.persistence.sample_base import SampleBase
from components.sample.configuration.sample_constants import DB_PATH

if TYPE_CHECKING:
    from digitalpy.core.zmanager.request import Request
    from digitalpy.core.zmanager.response import Response
    from digitalpy.core.digipy_configuration.configuration import Configuration
    from digitalpy.core.zmanager.action_mapper import ActionMapper


class SamplePersistenceController(Controller):
    """this class is responsible for handling the persistence of the sample
    component. It is responsible for creating, removing and retrieving records.
    """

    def __init__(
        self,
        request: 'Request',
        response: 'Response',
        sync_action_mapper: 'ActionMapper',
        configuration: 'Configuration',
    ):
        super().__init__(request, response, sync_action_mapper, configuration)
        self.ses = self.create_db_session()

    def create_db_session(self) -> Session:
        """open a new session in the database

        Returns:
            Session: the session connecting the db
        """
        engine = create_engine(DB_PATH)
        # create a configured "Session" class
        SessionClass = sessionmaker(bind=engine)

        SampleBase.metadata.create_all(engine)

        # create a Session
        return SessionClass()

    # Begin methods for greeting table


    def save_greeting(self, greeting: Greeting, *args, **kwargs) -> 'DBGreeting':
        if not isinstance(greeting, Greeting):
            raise TypeError("'Greeting' must be an instance of Greeting")

        db_greeting = DBGreeting()
        db_greeting.oid = greeting.oid
        db_greeting.message = greeting.message
        db_greeting.language = greeting.language
        self.ses.add(db_greeting)
        self.ses.commit()
        return db_greeting


    def remove_greeting(self, greeting: Greeting, *args, **kwargs):
        if not isinstance(greeting, Greeting):
            raise TypeError("'Greeting' must be an instance of Greeting")
        greeting_db = self.get_greeting(oid=greeting.oid)[0]
        self.ses.delete(greeting_db)
        self.ses.commit()

    def get_greeting(self, message:Union['str', None] = None, language:Union['str', None] = None, oid: 'str' = None, *args, **kwargs) -> List[DBGreeting]:

        query = self.ses.query(DBGreeting)

        if oid != None:
            query = query.filter(DBGreeting.oid == oid)
        if message != None:
            query = query.filter(DBGreeting.message == message)
        if language != None:
            query = query.filter(DBGreeting.language == language)

        return query.all()


    def get_all_greeting(self, *args, **kwargs) -> list[DBGreeting]:
        return self.ses.query(DBGreeting).all()

    def update_greeting(self, greeting: Greeting, *args, **kwargs):
        if not isinstance(greeting, Greeting):
            raise TypeError("'greeting' must be an instance of Greeting")
        greeting_db = self.get_greeting(oid = greeting.oid)[0]
        greeting_db.message = greeting.message
        greeting_db.language = greeting.language
        self.ses.commit()

    # Begin methods for greeting table

    # Begin methods for error table


    def save_error(self, error: Error, *args, **kwargs) -> 'DBError':
        if not isinstance(error, Error):
            raise TypeError("'Error' must be an instance of Error")

        db_error = DBError()
        db_error.oid = error.oid
        self.ses.add(db_error)
        self.ses.commit()
        return db_error


    def remove_error(self, error: Error, *args, **kwargs):
        if not isinstance(error, Error):
            raise TypeError("'Error' must be an instance of Error")
        error_db = self.get_error(oid=error.oid)[0]
        self.ses.delete(error_db)
        self.ses.commit()

    def get_error(self, oid: 'str' = None, *args, **kwargs) -> List[DBError]:

        query = self.ses.query(DBError)

        if oid != None:
            query = query.filter(DBError.oid == oid)

        return query.all()


    def get_all_error(self, *args, **kwargs) -> list[DBError]:
        return self.ses.query(DBError).all()

    def update_error(self, error: Error, *args, **kwargs):
        if not isinstance(error, Error):
            raise TypeError("'error' must be an instance of Error")
        error_db = self.get_error(oid = error.oid)[0]
        self.ses.commit()

    # Begin methods for error table


    def __getstate__(self) -> object:
        state: dict = super().__getstate__()  # type: ignore
        if "ses" in state:
            del state["ses"]
        return state

    def __setstate__(self, state: dict) -> None:
        self.__dict__.update(state)
        self.ses = self.create_db_session()
