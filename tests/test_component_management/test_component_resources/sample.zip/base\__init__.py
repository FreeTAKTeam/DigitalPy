"""This module contains all the supporting components without business logic
it should also be noted that the component action mapper must be exposed as action mapper.
"""
from .sample_action_mapper import SampleActionMapper as ActionMapper
