# pylint: disable=invalid-name
from digitalpy.core.domain.node import Node
from digitalpy.core.domain.relationship import Relationship, RelationshipType

from typing import TYPE_CHECKING
# iterating associations

class Greeting(Node):
    """"""
    def __init__(self, model_configuration, model, oid=None, node_type="Greeting") -> None:
        super().__init__(node_type, model_configuration=model_configuration, model=model, oid=oid)
        self._message: 'str' = None
        self._language: 'str' = None

    @property
    def message(self) -> 'str':
        """"""
        return self._message

    @message.setter
    def message(self, message: 'str'):
        message = str(message)
        if not isinstance(message, str):
            raise TypeError("'message' must be of type str")
        self._message= message

    @property
    def language(self) -> 'str':
        """"""
        return self._language

    @language.setter
    def language(self, language: 'str'):
        language = str(language)
        if not isinstance(language, str):
            raise TypeError("'language' must be of type str")
        self._language= language
